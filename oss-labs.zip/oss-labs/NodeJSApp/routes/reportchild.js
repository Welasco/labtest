reportnum = 1;
for (let index = 1; index < 2147483647; index++) {
    reportnum = reportnum * index;
}
