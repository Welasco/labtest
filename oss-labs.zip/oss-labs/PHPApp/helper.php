<?php

require __DIR__ . '/vendor/autoload.php';

use React\EventLoop\Factory;
use React\ChildProcess\Process;

function num_cpu(): int {
    if (defined ( 'PHP_WINDOWS_VERSION_MAJOR' )) {
		$str = trim ( shell_exec ( 'wmic computersystem get NumberOfLogicalProcessors 2>&1' ) );
		if (! preg_match ( '/(\d+)/', $str, $matches )) {
			throw new \RuntimeException ( 'wmic failed to get number of logical cores on windows!' );
		}
		return (( int ) $matches [1]);
    } 
    
    $ret = @shell_exec ( 'nproc' );
	if (is_string ( $ret )) {
		$ret = trim ( $ret );
		if (false !== ($tmp = filter_var ( $ret, FILTER_VALIDATE_INT ))) {
			return $tmp;
		}
    }
    
	if (is_readable ( '/proc/cpuinfo' )) {
		$cpuinfo = file_get_contents ( '/proc/cpuinfo' );
		$count = substr_count ( $cpuinfo, 'processor' );
		if ($count > 0) {
			return $count;
		}
	}
}


function generateChildReport(){
    $loop = React\EventLoop\Factory::create();
    $command="php reportchild.php";

    if (defined ( 'PHP_WINDOWS_VERSION_MAJOR' )) {    
        $process = new Process($command, null, null, array());
        $process->start($loop);
        $process->on('exit', function ($exitcode) {
            echo 'exit with ' . $exitcode . PHP_EOL;
        });
    } else {
        $process = new React\ChildProcess\Process($command);
        $process->start($loop);
        $process->stdout->on('data', function ($chunk) {
            echo $chunk;
        });
        $process->on('exit', function($exitCode, $termSignal) {
            echo 'Process exited with code ' . $exitCode . PHP_EOL;
        });
        $loop->run();
    }
}

function startdbconnections(): int {
    $loop = React\EventLoop\Factory::create();
    $command = 'node C:\Projects\OSS-Labs\NodeJSApp\tools\dbconnections.js www.bing.com 80 1000';

    if (defined ( 'PHP_WINDOWS_VERSION_MAJOR' )) {    
        $process = new Process($command, null, null, array());
        $process->start($loop);
        $process->on('exit', function ($exitcode) {
            echo 'exit with ' . $exitcode . PHP_EOL;
        });
        return $process->getPid();
    } else {
        $process = new React\ChildProcess\Process($command);
        $process->start($loop);
        $process->stdout->on('data', function ($chunk) {
            echo $chunk;
        });
        $process->on('exit', function($exitCode, $termSignal) {
            echo 'Process exited with code ' . $exitCode . PHP_EOL;
        });
        $loop->run();
        return $process->getPid();
    }
}
function kill($pid){ return stripos(php_uname('s'), 'win')>-1 
    ? exec("taskkill /F /PID $pid") : exec("kill -9 $pid"); }

function processKill($pid) {
    $isRunning = false;
    if (defined ( 'PHP_WINDOWS_VERSION_MAJOR' )) {
        $out = [];
            exec("TASKLIST /FO LIST /FI \"PID eq $pid\"", $out);
            if(count($out) > 1) {
                $isRunning = true;
            }
    }  elseif(posix_kill(intval($prevPid), 0)) {
        $isRunning = true;
    }
    
    if($isRunning) {
        kill($pid);  
    }
}