<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use \Slim\Views\PhpRenderer;

ini_set('memory_limit', '1024M');
ini_set('max_execution_time', 300);

require './vendor/autoload.php';
include 'helper.php';

session_start();

if (!isset($_SESSION['marketingglobal'])){
    $_SESSION['marketingglobal'] = 0;
}

if (!isset($_SESSION['userList'])){
    $_SESSION['userList'] = array();
}

if (!isset($_SESSION['pid'])){
    $_SESSION['pid'] = 0;
}

$app = new \Slim\App();
$container = $app->getContainer();
$container['view'] = function ($c) {
    $view = new \Slim\Views\Twig('');
    return $view;
};

$app->get('/', function ($request, $response, $args) {
    return $this->view->render($response, 'index.html');
});

$app->get('/api/marketing/', function (Request $request, Response $response) {
    $jsonResponse = array("response" => "Response OK");
    ++$_SESSION['marketingglobal'];
    $marketingresult = $_SESSION['marketingglobal']%2;
    if($marketingresult == 0){
        return $response->withHeader('Content-type', 'application/json')->withJson($jsonResponse, 200);
    } else {
        return $response->withStatus(500);
    }
});

function generateid ($userID) {
    $numbers = $userID / 8;
    $arr = array();
    for ($i = 0; $i < $numbers; $i++) {
        array_push($arr, $i);
    }
    return $arr;
};

$app->get('/api/users', function (Request $request, Response $response) {
    $id = floor(rand(0,100) * 5) + 1;
    $jsonResponse = array("response" => "User Added Num: {$id}");
    $userID = 10000 * 1024;
    $user = generateid($userID);
    array_push($_SESSION['userList'],$user);
    $userResponse = array();
    return $response->withHeader('Content-type', 'application/json')->withJson($jsonResponse, 200);
});

$reportCount = num_cpu();
$reportnum = 1;

$app->get('/api/reports', function (Request $request, Response $response) {
    global $reportCount;
    global $reportnum;
    $jsonResponse = array("response" => "Report generated in background.");

    if ($reportCount >= 3) {
        $reportloop = $reportCount-2;
        for ($report = 1; $report <= $reportloop; $report++) {
            generateChildReport();
        }
    }

    for ($index = 1; $index < 2147483640; $index++) {
        $reportnum = $reportnum * $index;
    }

    return $response->withHeader('Content-type', 'application/json')->withJson($jsonResponse, 200);
});


$app->get('/api/admin/connect', function (Request $request, Response $response) {
    $currentPid = $_SESSION['pid'];
    $jsonResponse = array("response" => "Database Connections opened.");

    if ($currentPid == null || $currentPid == 0) {
        $tempId = startdbconnections();
        $_SESSION['pid'] = $tempId;
        $jsonResponse = array("response" => "Database Connections opened.");  
        return $response->withHeader('Content-type', 'application/json')->withJson($jsonResponse, 200);
      }
      else{
        $jsonResponse = array("response" => "Database Connections already opened.");
        return $response->withHeader('Content-type', 'application/json')->withJson($jsonResponse, 200);
      }
});


$app->get('/api/admin/disconnect', function (Request $request, Response $response) {
    $currentPid = $_SESSION['pid'];
    if($currentPid !=null && $currentPid!=0){
        processKill($currentPid);
        $_SESSION['pid'] = 0;
        $jsonResponse = array("response" => "Database Connections closed.");
        return $response->withHeader('Content-type', 'application/json')->withJson($jsonResponse, 200);
    } else {
        $jsonResponse = array("response" => "Database Connections already closed.");
        return $response->withHeader('Content-type', 'application/json')->withJson($jsonResponse, 200);
    }
});


$app->run();
