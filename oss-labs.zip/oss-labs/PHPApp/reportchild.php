<?php

$reportnum = 1;

for ($index = 1; $index < 2147483647; $index++) {
    $reportnum = $reportnum * $index;
}
