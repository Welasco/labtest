./mvnw.cmd clean package
cp .\target\javaapp-0.0.1-SNAPSHOT.jar javaapp.jar