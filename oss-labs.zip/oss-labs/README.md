# OSS Labs
>Please pick your preferred programming language for this activity:
1.  JAVA
2. PHP
3. NodeJS
4. Python
 
#### Lab 1 
**HTTP 500 Intermittent.** The customer Contoso has a Web application that is randomly failing with HTTP status code 500. Whenever a user opens the Web portal and click on Marketing button most of the time it throws an error. Your goal is to identify why the Web application is intermittently failing.


#### Lab 2
**Memory Leak issue.** The customer Contoso is also complaining about a performance deterioration in the server, unexpected behaviors and some exceptions. Whenever they click on Add User button and start adding users to the system the problem appears. Your goal is to identify what is the causing those symptoms.
 ***node bin/www > app.log 2>&1
 java -Xmx1024M -jar .\javaapp-0.0.1-SNAPSHOT.jar
 C:\oss-labs.\mvnw.cmd clean package

#### Lab 3
 **High CPU.** The customer Contoso is complaining about the CPU utilization of his server. When users start navigating to the reports section in the web application the CPU utilization increases. Your goal is to identify the root cause of the high CPU utilization.

#### Lab 4
 **SNAT Port Exhaustion.** The customer Contoso is complaining about intermittent database connection issues. When users start using the Admin Page they observe too many connections opened in the network. Your goal is to identify from where the connections are being opened, identify the target, the number of connections that were established and the targeted port number.	

  (netstat -aonp TCP | select-string "remote ip address").count    

#### Lab 5
 **Docker Container.** The customer Contoso wants to containerize his Web application. The application code is setup to be listening under the port 8080. Your goal is to help them to containerize their application and publish it under the port 51123.
