import subprocess
import json
import os
from pathlib import Path

class admin:
    proc = ''
    pid = 0
    responseBuild = '''
            {
                "response" : "initializing"
            }
    '''
    response = json.loads(responseBuild)
    def connect(self):
        if self.pid == 0:
            mod_path = Path(__file__).parent
            relative_path = '../NodeJSApp/tools/dbconnections.js'
            dbconnectionpath = str((mod_path / relative_path).resolve())
            self.proc = subprocess.Popen(['node', dbconnectionpath, 'www.bing.com', '80', '1000'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            self.pid = self.proc.pid
            self.response['response'] = "Database Connections opened"

            return json.dumps(self.response)
        else:
            self.response['response'] = "Database Connections already opened"
            return json.dumps(self.response)
            

    def disconnect(self):
        if self.pid != 0:
            self.proc.kill()
            self.pid = 0
            res = '''
            {
                "response" : "Database Connections closed"
            }
            '''
            self.response['response'] = "Database Connections closed"
            return json.dumps(self.response)
        else:
            self.response['response'] = "Database Connections already closed"
            return json.dumps(self.response)
