#!/usr/bin/env python3
from flask import Flask, request, send_file, Response
import os
import random
import json
from flask import jsonify
from admin import admin
from marketing import marketing
from reports import reports 

app = Flask(__name__, static_url_path='',
            static_folder=os.path.abspath('./public'))

@app.route('/')
def index():
    return send_file('./public/index.html')

admin = admin()
@app.route('/api/admin/connect/')
def adminconnect():
    res = app.response_class(
        response=admin.connect(),
        mimetype='application/json'
    )
    return res

@app.route('/api/admin/disconnect/')
def admindisconnect():
    res = app.response_class(
        response=admin.disconnect(),
        mimetype='application/json'
    )
    return res

marketing = marketing()
@app.route('/api/marketing/')
def marketingroute():
    marketingrunres = marketing.marketingrun()
    checkresponse = json.loads(marketingrunres)
    if checkresponse['response']=="Response OK":
        res = app.response_class(
            response=marketingrunres,
            mimetype='application/json'
        )
    else:
        res = app.response_class(
            response=marketingrunres,
            mimetype='application/json',
            status=500
        )
    return res    

def generateid(userID):
    numbers = int(userID/8)
    data = []
    i=0
    for i in range(numbers):
        i=i+1
        data.append(i)
    return data

userslist = []
@app.route('/api/users')
def userslistMethod():
    userID = 200000 * 1024
    user = generateid(userID)
    userslist.append(user)
    userslist.append(userslist)
    output = "User Added Num: " +str(random.randint(1,1100))
    return jsonify({"response":output})


reports = reports()
@app.route('/api/reports')
def getreports():
    res = app.response_class(
        response=reports.reportsrun(),
        mimetype='application/json'
    )
    return res
          

if __name__ == "__main__":
    app.run(host='0.0.0.0',debug=True)