import json

class marketing:
    responseBuild = '''
            {
                "response" : "initializing"
            }
    '''
    response = json.loads(responseBuild)
    marketingglobal = 0
    def marketingrun(self):
        self.marketingglobal = self.marketingglobal+1
        marketingmath = self.marketingglobal%2
        if marketingmath == 0:
            self.response['response'] = "Response OK"
            return json.dumps(self.response)
        else:
            self.response['response'] = "Response Error"
            return json.dumps(self.response)