import json
import subprocess
import multiprocessing
from sys import platform

class reports:
    responseBuild = '''
            {
                "response" : "initializing"
            }
    '''
    response = json.loads(responseBuild)
    reportnum = 1  
    def reportsrun(self):
        reportCount = multiprocessing.cpu_count()
        if reportCount >= 3:
            reportloop = reportCount -2
            for report in range(reportloop):
                if platform == "linux" or platform == "linux2":
                    subprocess.Popen(['python3', 'reportchild.py'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
                elif platform == "win32":
                    subprocess.Popen(['python', 'reportchild.py'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)

        for index in range(1214748364):
            self.reportnum * index
          
        self.response['response'] = "Report generated in background"
        return json.dumps(self.response)